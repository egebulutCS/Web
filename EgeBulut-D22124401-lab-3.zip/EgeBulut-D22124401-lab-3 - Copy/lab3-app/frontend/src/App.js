import React, { useEffect, useState } from 'react';
import axios from 'axios';

function App() {

  const [pageNo, setPageNo] = useState(0);
  const [dataList, setDataList] = useState([]);

  useEffect(() => {
    axios.get(`http://localhost:3001/hackernews?page=${pageNo}`)
    .then((response) => {setDataList((val) => [...val, ...response.data.hits]);
    });
  }, [pageNo]);

  return (
    <div class="hackernews">
      <table id="newsTable">
          <thead>
              <tr>
                  <th>Title</th>
                  <th>Author</th>
                  <th>Number of Comments</th>
                  <th>Points</th>
              </tr>
              { 
                dataList.map((data, k) => 
                  <tr key={k}>
                    <td><a href={data.url}>{data.title}</a></td>
                    <td>{data.author}</td>
                    <td>{data.num_comments}</td>
                    <td>{data.points}</td>
                  </tr>
                )
              }
          </thead>
        </table>
        <button onClick={() => setPageNo((val) => val+1)}>More</button>
    </div>
  );
}

export default App;
