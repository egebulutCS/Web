const express = require("express");
const cors = require("cors");

const app = express();
const port = 3001;

app.use(cors());

app.get('/hackernews', (req, res) => {
    res.redirect(307, `https://hn.algolia.com/api/v1/search?query=redux&page=${req.query.page}`);
});

app.listen(port, () => {
    console.log(`Listening on port: ${port}`);
})

// Set-ExecutionPolicy RemoteSigned
// Set-ExecutionPolicy Restricted